@echo off
setlocal EnableDelayedExpansion
title System Boot
mode con: cols=140 lines=45
:: Pre-cargamos variables para no gastar CPU calculando en los bucles
set "chars=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
set "hex=0123456789ABCDEF"
set "wall=████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████"

:: ============================================================
::  FASE 1 - BIOS
:: ============================================================
color 07
cls
echo.
echo   American Megatrends International, LLC.
echo   Processor: Intel(R) Core(TM) i9-14900K @ 6.00GHz
echo   Memory Test: 32768MB OK
echo.
echo   [!!!] SMART Status: CRITICAL_FAILURE
echo   [!!!] Reallocated Sector Count: 8472
timeout /t 3 >nul
cls
echo   Starting Windows...
for /l %%a in (1,1,15) do (<nul set /p "=." & timeout /t 1 >nul)
timeout /t 1 >nul
cls

:: ============================================================
::  FASE 2 - INFECCION SILENCIOSA + PARPADEO
:: ============================================================
title Windows Logon
color 07
echo   Welcome... Please wait.
timeout /t 2 >nul
for /l %%i in (1,1,6) do (
    color 0C
    timeout /t 0 >nul 2>&1
    color 07
    timeout /t 0 >nul 2>&1
)
cls

:: ============================================================
::  FASE 3 - PROPAGACION WANNA CRY / ILOVEYOU (Solo texto)
:: ============================================================
title Security Alert
color 0E
cls
echo.
echo   [WANNA CRY MODULE] Scanning 192.168.1.0/24...
for /l %%i in (1,1,5) do (
    set /a "ip=!random! %% 254 + 1"
    echo   [FOUND] 192.168.1.!ip!:445 - VULNERABLE (SIMULATED)
    timeout /t 1 >nul
)
echo.
echo   [ILOVEYOU MODULE] Spamming contacts...
for /l %%i in (1,1,5) do (
    echo   [SENT] LOVE-LETTER-FOR-YOU.TXT.vbs to contact_%%i@email.com
    timeout /t 0 >nul 2>&1
)
timeout /t 2 >nul
cls

:: ============================================================
::  FASE 4 - VOLCADO HEXADECIMAL PETYA
:: ============================================================
title Disk Cryptor
color 0C
cls
echo.
echo   PETYA SIMULATION - OVERWRITING MASTER BOOT RECORD
for /l %%s in (1,1,12) do (
    set "hexline=0x!random:~-1!!random:~-1!!random:~-1!0: "
    for /l %%b in (1,1,24) do (
        set /a "h1=!random! %% 16"
        set /a "h2=!random! %% 16"
        set "hexline=!hexline!!hex:~%h1%,1!!hex:~%h2%,1! "
    )
    echo   !hexline!
    timeout /t 1 >nul
)
timeout /t 2 >nul
cls

:: ============================================================
::  FASE 5 - WANTACRY RANSOMWARE (Solo texto)
:: ============================================================
title @WanaDecryptor@
color 0C
cls
echo.
echo  ╔════════════════════════════════════════════════════════════════════════════════╗
echo  ║               !!! YOUR FILES HAVE BEEN ENCRYPTED BY WANNA CRY !!!               ║
echo  ╠════════════════════════════════════════════════════════════════════════════════╣
echo  ║  Encrypted Files Preview:                                                      ║
for /l %%i in (1,1,5) do (
    echo  ║  C:\Windows\System32\config\!random!_!random!.WNCRY                             ║
)
echo  ║  ... and 84,732 more files.                                                    ║
echo  ║  Send $600 to BTC: 1BrufZ57QXS4FG2Mp3y (FAKE)                                 ║
echo  ╚════════════════════════════════════════════════════════════════════════════════╝
timeout /t 4 >nul
cls

:: ============================================================
::  FASE 6 - BARRA DE CIFRADO
:: ============================================================
set "prog=0"
:wcbar
set /a "prog+=2"
if !prog! gtr 100 set "prog=100"
set "pfill="
set "pempty=                                                                        "
for /l %%a in (1,1,!prog!) do set "pfill=!pfill!█"
set /a "rem=100-prog"
for /l %%a in (1,1,!rem!) do set "pempty=!pempty!░"
cls
color 0C
echo.
echo   [!pfill!!pempty!] !prog!%%
echo   Current file: C:\Windows\!random!.WNCRY
if !prog! lss 100 (timeout /t 1 >nul & goto wcbar)
timeout /t 2 >nul

:: ============================================================
::  FASE 7 - SALINEWIN + BONZI + YOU ARE AN IDIOT (Solo texto)
:: ============================================================
title Multiple Threats
color 0E
cls
echo.
echo   [SALINEWIN] System salinity: 300%% - Hardware failing.
echo   [BONZI] "I can't stop helping! My banana database is gone!"
echo   [IDIOT] 
echo    ██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗
echo    ██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
echo    ███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██████╔╝
echo    ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝
echo   HA HA HA HA HA
timeout /t 3 >nul
cls

:: ============================================================
::  FASE 8 - REGISTRO FALSO
:: ============================================================
title Regedit
color 0F
cls
echo   Windows Registry Editor Version 5.00
echo   [HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run]
echo   "SystemService"="C:\\Windows\\Temp\\svchost_x.exe"
echo   "WannaCry"="C:\\ProgramData\\taskdl.exe"
echo   "Bonzi"="C:\\BonziBUDDY\\BonziBUDDY.exe -corrupted"
echo   [HKEY_CURRENT_USER\SOFTWARE\Classes\.exe] @="exefile_infected"
timeout /t 2 >nul
cls

:: ============================================================
::  FASE 9 - MEMZ MATRIX OVERDRIVE
:: ============================================================
title MEMZ
color 0A
cls
for /l %%i in (1,1,15) do (
    set "line="
    for /l %%j in (1,1,120) do (
        set /a "idx=!random! %% 62"
        if "!idx!"=="0" set "line=!line!!chars:~%idx%,1!"
        if not "!idx!"=="0" set "line=!line! "
    )
    echo !line!
    timeout /t 1 >nul
)
timeout /t 1 >nul
cls

:: ============================================================
::  FASE 10 - SIMULACION DE VENTANAS EMERGENTES (SIN START)
:: ============================================================
title Cascade Failure
color 0C
cls
:: En lugar de abrir ventanas reales, dibujamos cuadros superpuestos
echo   [SYSTEM ERROR]       [WARNING]            [FATAL]              [ALERT]
echo   Access Denied        High CPU             Disk Fail            Mem Corrupt
echo   ================================================================
echo   [CRYPT]               [BONZI]              [IDIOT]              [SALT]
echo   Encrypting C:        Help me!             HA HA HA             300% Salt
timeout /t 2 >nul
cls
echo          [SYSTEM ERROR]       [WARNING]            [FATAL]              [ALERT]
echo          Access Denied        High CPU             Disk Fail            Mem Corrupt
echo          ================================================================
echo          [CRYPT]               [BONZI]              [IDIOT]              [SALT]
echo          Encrypting C:        Help me!             HA HA HA             300% Salt
timeout /t 1 >nul
cls
:: Mas capas de "ventanas" falsas desplazadas
echo            [FATAL]         [SYSTEM ERROR]     [IDIOT]        [CRYPT]
echo            Disk Fail       Access Denied      HA HA HA      Encrypting
echo            ================================================================
echo            [ALERT]         [WARNING]          [SALT]         [BONZI]
echo            Mem Corrupt     High CPU           300% Salt      Help me!
timeout /t 1 >nul
cls

:: ============================================================
::  FASE 11 - CORRUPCION VISUAL DE PANTALLA (LLENADO DE RAM FALSO)
:: ============================================================
title MEMORY_OVERFLOW
color 0A
:: Usamos una variable pre-creada para no gastar CPU concatenando caracteres
for /l %%y in (1,1,40) do (
    echo !wall!
    timeout /t 0 >nul 2>&1
)
timeout /t 2 >nul
cls

:: ============================================================
::  FASE 12 - CAOS DE COLORES SIN PROCESOS
:: ============================================================
title !!!
:: Efecto psicodélico de colores rapido sin abrir nada
for /l %%i in (1,1,15) do (
    set /a "cc=!random! %% 15"
    if !cc!==0 set "cc=1"
    color 0!cc!
    cls
    echo.
    echo   [!!!!!] SYSTEM COMPROMISE LEVEL: %%i0%%
    echo   ERROR CODE: 0x!random!!random!!random!
    timeout /t 0 >nul 2>&1
)

:: ============================================================
::  FASE 13 - BSOD REALISTA
:: ============================================================
title 
color 17
cls
echo.
echo   A problem has been detected and Windows has been shut down to prevent damage
echo   to your computer.
echo.
echo   PROCESS_HAS_LOCKED_PAGES
echo.
echo   *** STOP: 0x00000076 (0x0000000000000000,0xFFFFFA8006B7A060,0x0000000000000001,0x0000000000000000)
echo.
echo   Collecting data for crash dump...
timeout /t 5 >nul
cls

:: ============================================================
::  FASE 14 - PANTALLA NEGRA CINEMATICA
:: ============================================================
color 0A
timeout /t 2 >nul
echo.
echo   You thought it was real.
timeout /t 2 >nul
echo.
echo   Your heart rate increased.
timeout /t 2 >nul
echo.
echo   But your files are safe. Your OS is intact.
timeout /t 2 >nul
echo.
echo   Real malware happens in silence. This was just theater.
timeout /t 3 >nul
cls

:: ============================================================
::  FASE 15 - INFORME DE DAÑO CERO
:: ============================================================
color 07
title System Diagnosis
cls
echo.
echo   ╔══════════════════════════════════════════════════════════════╗
echo   ║                      DIAGNOSTIC REPORT                      ║
echo   ╠══════════════════════════════════════════════════════════════╣
echo   ║                                                              ║
echo   ║  Malware Simulated: MEMZ, Petya, WannaCry, ILOVEYOU,        ║
echo   ║                    SalineWin, U R Idiot, BonziBuddy          ║
echo   ║                                                              ║
echo   ║  ---------------------------------------------------------------- ║
echo   ║  Extra RAM Consumed:          0 KB                          ║
echo   ║  Extra Processes Spawned:     0                            ║
echo   ║  Files Modified:              0                            ║
echo   ║  Disk Space Used:             0 Bytes                      ║
echo   ║  Actual Damage:               ZERO                         ║
echo   ║  ---------------------------------------------------------------- ║
echo   ║                                                              ║
echo   ╚══════════════════════════════════════════════════════════════╝
echo.
echo   Press any key to safely exit...
pause >nul
color 07
exit